
import javax.swing.JFrame;

public abstract class Frames extends JFrame{

	public abstract void initialiseFrame();
	
}

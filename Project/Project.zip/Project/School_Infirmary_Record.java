/* NICHOLAS WONG
 * BI19110023
 * OOP KK14203 SECTION 1
 * INDIVIDUAL PROJECT - SCHOOL INFIRMARY RECORD APP
 */

public class School_Infirmary_Record {

	public static void main(String[] args) {
		
		new LoginFrame();

	}

}


public interface ButtonDetails {
	
	public void makeBtn(int a, int b, int c);
	public void btnEvent(int d, int e);
	public void printDetails(int f);
	
}
